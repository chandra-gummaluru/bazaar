from setuptools import setup, find_packages

setup(
    name='bazaar',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='Chandra Gummaluru',
    description='a bazaar simulator',
)